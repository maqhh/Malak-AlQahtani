package com.example.springday1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springday1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
