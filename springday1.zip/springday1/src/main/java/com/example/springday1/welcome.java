package com.example.springday1;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class welcome {
    @GetMapping("/hey")
    public String hey(){
        return "hi";

    }
    @GetMapping("/Name")
    public String Name(){
        return "malak";

    }
    @GetMapping("/check")
    public String Old(){
        return "23";
    }
}
