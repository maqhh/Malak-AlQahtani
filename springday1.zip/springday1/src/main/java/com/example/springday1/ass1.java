package com.example.springday1;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ass1 {
    @GetMapping("/name")
    public String name(){
        return "My name is malak";

    }
    @GetMapping("/age")
    public String age(){
        return "My age is 23";
    }
    @GetMapping("/check/staus")
    public String check(){
        return "everything ok";
    }
    @GetMapping("/health")
    public String health(){
        return "server health is up and running";
    }
}
